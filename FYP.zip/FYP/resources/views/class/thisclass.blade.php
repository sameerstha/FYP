<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{$classroom->class_name}}
        </h2>
        <p>Class Code: {{$classroom->class_code}}</p>
    </x-slot>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>About Class</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
    </head>
    <body>
        <section style="padding-top:60px;">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                Add Post
                            </div>
                            <div class="card-body">
                                @if($errors->any())
                                @foreach($errors->all() as $error)
                                    <div class="alert alert-danger" role="alert">
                                        {{$error}}
                                    </div>
                                @endforeach
                                @endif
                                <form method="POST" action="{{url('/files')}}" enctype="multipart/form-data">
                                    @csrf
                                    <div class="form-group">
                                        <input type="hidden" name="classroom_id" value="{{$classroom->id}}" class="form-control"/>
                                    </div>
                                    <div class="form-group">
                                        <input type="text" name="title" class="form-control" placeholder="Enter post title"/>
                                    </div>
                                    <div class="form-group">
                                        <input type="text" name="description" class="form-control" placeholder="Enter your post"/>
                                    </div>
                                    <div class="form-group" style="padding-top:10px;">
                                        <label for="file">Choose file</label>
                                        <input type="file" class="form-control" name="file" multiple/>
                                    </div>
                                    <div class="form-group" style="padding-top:12px;">
                                        <button type="submit" class="btn btn-success">Submit</button>
                                    </div>
                                </form>
                                <!--<div>
                                @if($errors->any())
                                @foreach($errors->all() as $error)
                                    <div class="alert alert-danger" role="alert">
                                        {{$error}}
                                    </div>
                                @endforeach
                                @endif
                                
                                <table border="1">
                                    <tr>
                                    <th>S.N</th>
                                    <th>Title</th>
                                    <th>Description</th>
                                    <th>View</th>
                                    <th>Download</th>
                                    </tr>
                                    @foreach($classroom->documents as $key=>$data)
                                 
                                    <tr>
                                        <td>{{++$key}}</td>
                                        <td>{{$data->title}}</td>
                                        <td>{{$data->description}}</td>
                                        <td><a href="/files/{{$data->id}}">View</a></td>
                                        <td><a href="/file/download/{{$data->file}}">Download</a></td>
                                    </tr>
                                    @endforeach
                                </div>
                                
                            </div>-->
                            <div>
                                @foreach($classroom->documents as $key=>$data)
                                <section>
                                <div class="card border-primary mb-3" style="max-width:66rem;">
                                    <div class="card-header">{{$data->title}}</div>
                                    <div class="card-body">
                                    <p class="card-text">{{$data->description}}</p>
                                    <!--{{$data->file}};-->
                                    @if($data->file)
                                        <iframe src="/public/storage/{{$data->file}}" width="160px" height="100px">
                                    @endif
                                    <div>
                                    </div>
                                </div>
                                
                                </section>
                                @endforeach
                            </div>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>
    </body>
    </html>
</x-app-layout>