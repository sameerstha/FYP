<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Classroom;
use App\Models\Document;

class DashboardController extends Controller

{
    //
    public function index()
    {
        return view('dashboard');
    }

    public function teacherprofile()
    {
        return view('teacherprofile');
    }

    public function studentprofile()
    {
        return view('studentprofile');
    }

    public function teacherclassroom()
    {
        return view('teacherclassroom');
    }
}