<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Classroom;
use App\Models\Document;

use Illuminate\Support\Facades\Storage;

class ClassroomController extends Controller
{
    //
    public function addClass()
    {
        return view('class.addclass');
    }

    public function createClass(Request $request)
    {
        $classroom = new Classroom();
        $classroom->class_name = $request->class_name;
        $classroom->class_code = $request->class_code;
        $classroom->save();
        return back()->with('class_added','Class is successfully created!');
    }

    public function getClass()
    {
        if(Auth::user()->hasRole('admin'))
        {
            $classrooms = Classroom::orderBy('id','DESC')->get();
        }
        else
        {
            $classrooms = Auth::user()->classes->unique();
        }
        return view('class.classrooms',compact('classrooms'));
    }

    public function getClassByID($id)
    {
        $classroom = Classroom::where('id',$id)->with('documents')->first();
        return view('class.thisclass',compact('classroom','id'));
    }

    public function deleteClass($id)
    {
        Classroom::where('id',$id)->delete();
        return back()->with('class_deleted','Class has been deleted successfully!');
    }

    public function editClass($id)
    {
        $classroom = Classroom::find($id);
        return view('class.editclass',compact('classroom'));
    }

    public function updateClass(Request $request)
    {
        $classroom = Classroom::find($request->id);
        $classroom->class_name = $request->class_name;
        $classroom->class_code = $request->class_code;
        $classroom->save();
        return back()->with('class_updated','Class has been updated successfully!');
    }

    public function joinClass()
    {
        return view('class.joinclass');
    }

    public function joinNewClass(Request $request)
    {   
        $class_code = $request->class_code;
        $classroom = Classroom::where('class_code',$class_code)->first();
        $classroom_id = $classroom->id;
        $user = auth()->user();
        $user->classes()->attach($classroom->id);
        return view('class.thisclass',compact('classroom'));
    }

    public function storePost(Request $request)
    {
        $data=  new Document();
        if($request->hasFile('file')){
            $file=$request->file('file');
            $ext = $file->getClientOriginalExtension();
            $filename = Storage::disk('public')->put('file',$file);
            $data->file=$filename;
        } 
        //$user = auth()->user();
        //$user->documents()->attach($document->id);
        $data->classroom_id = $request->classroom_id;
        $data->title=$request->title;
        $data->description=$request->description;
        // dd($data);
        $data->save();
        return redirect()->back();
    }

    /*public function index()
    {
        $file=Document::all();
 
        return view('class.thisclass',compact('file'));
    }

    public function show($id)
    {
        $data=Document::find($id);
        return view('class.details',compact('data'));
    }

    public function download($file)
    {
        //return Storage::download($file);
        // return response()->download('public'.$file);
        return Storage::download($file);
    }*/
}