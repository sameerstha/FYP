<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Student Portal Website')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>All Classes</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
    </head>
    <body>
        <section style="padding-top:60px;">
            <div class="container">
                <div class="row">
                    <div class="col-md-8 offset-md-2">
                        <div class="card">
                            <div class="card-header">
                                All Classes
                                    <?php if(Auth::user()->hasRole('admin')): ?>
                                        <a href="/addclass" class="btn btn-success">Add Class</a>
                                    <?php endif; ?>
                                    <?php if(Auth::user()->hasRole('teacher')): ?>
                                        <a href="/addclass" class="btn btn-success">Add Class</a>
                                    <?php endif; ?>
                                <a href="/joinClass" class="btn btn-success">Join Class</a>
                            </div>
                            <div class="card-body">
                                <?php if(Session::has('class_deleted')): ?>
                                    <div class="alert alert-success" role="alert">
                                        <?php echo e(Session::get('class_deleted')); ?>

                                    </div>
                                <?php endif; ?>
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Class_Name</th>
                                            <th>Class_Code</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $classrooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classroom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($classroom->class_name); ?></td>
                                                <td><?php echo e($classroom->class_code); ?></td>
                                                <td>
                                                    <a href="/editclass/<?php echo e($classroom->id); ?>" class="btn btn-secondary">Edit</a>
                                                    <a href="classrooms/<?php echo e($classroom->id); ?>" class="btn btn-success">View</a>
                                                    <a href="deleteclass/<?php echo e($classroom->id); ?>" class="btn btn-danger">Delete</a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>       
    </body>
    </html>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script><?php /**PATH C:\Users\shivaramshrestha\Desktop\FYP\FYP\resources\views/class/classrooms.blade.php ENDPATH**/ ?>