<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\ClassroomController;
use App\Http\Controllers\DocumentController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

/*
Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth'])->name('dashboard');
*/

//auth route for both
Route::group(['middleware' => ['auth']], function(){
    Route::get('/dashboard', [ClassroomController::class, 'getClass'])-> name
    ('dashboard');
    Route::get('/dashboard/joinclass', [ClassroomController::class, 'joinClass'])-> name
    ('dashboard.joinclass');
    Route::get('/dashboard/class', [DashboardController::class, 'class'])-> name
    ('dashboard.class');
});

//Teacher Profile
Route::group(['middleware' => ['auth', 'role:teacher']], function(){
    Route::get('/dashboard/teacherprofile', [DashboardController::class, 'teacherprofile'])-> name
    ('dashboard.teacherprofile');
});

//Student Profile
Route::group(['middleware' => ['auth', 'role:student']], function(){
    Route::get('/dashboard/studentprofile', [DashboardController::class, 'studentprofile'])-> name
    ('dashboard.studentprofile');
});

Route::get('/addclass',[ClassroomController::class,'addClass']);
Route::post('/createclass',[ClassroomController::class,'createClass'])->name('class.create');
Route::get('/classrooms',[ClassroomController::class,'getClass']);
Route::get('/classrooms/{id}',[ClassroomController::class,'getClassById']);
Route::get('/deleteclass/{id}',[ClassroomController::class,'deleteClass']);
Route::get('/editclass/{id}',[ClassroomController::class,'editClass']);
Route::post('/updateclass',[ClassroomController::class,'updateClass'])->name('class.update');

Route::get('joinClass',[ClassroomController::class,'joinClass']);
Route::post('joinedclass',[ClassroomController::class,'joinNewClass'])->name('class.join');

Route::post('/files',[ClassroomController::class,'storePost']);

/*
Route::get('/viewfiles',[ClassroomController::class,'index']);
Route::get('/files', 'ClassroomController@index');
Route::get('/files/{id}',[ClassroomController::class,'show']);
Route::get('/file/download/{file}',[ClassroomController::class,'download']);

Route::get('/files/create',[DocumentController::class,'create']);
Route::post('/files',[DocumentController::class,'store']);
Route::get('/files',[DocumentController::class,'index']);
Route::get('/files/{id}',[DocumentController::class,'show']);
Route::get('/file/download/{file}',[DocumentController::class,'download']);*/

require __DIR__.'/auth.php';